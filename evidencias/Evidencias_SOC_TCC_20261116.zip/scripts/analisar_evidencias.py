"""Recalcula os resultados documentais do TCC usando apenas a biblioteca padrão."""
from pathlib import Path
from collections import Counter
import csv, gzip, hashlib, json, statistics, sys

BASE = Path(__file__).resolve().parent
if (BASE/'fontes').is_dir():
    DATA=BASE
elif (BASE.parent/'fontes').is_dir():
    DATA=BASE.parent
else:
    DATA=BASE/'evidencias'
SRC=DATA/'fontes'
OUT=DATA/'resultados'
OUT.mkdir(parents=True,exist_ok=True)
events=[json.loads(x) for x in (SRC/'clinica-demo.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
assert len(events)==280
metrics=[x for x in events if x['event']=='panel.metrics']
by_run={}
for x in events:
    if x.get('run'):by_run.setdefault(x['run'],[]).append(x)
rows=[]
for metric in metrics:
    run=metric['run']; trail=by_run[run]
    scenario=next((x['scenario'] for x in trail if x.get('scenario')),None)
    triage=next((x for x in trail if x['event'] in ['soar.triaged','soar.manual_triaged']),{})
    row={'run':run,'scenario':scenario,'mode':metric['mode'],'outcome':metric['outcome'],
         'timestamp_metrics':metric['timestamp'],'provider':triage.get('provider','manual'),
         'severity':triage.get('severity'),'model_suggested_severity':triage.get('model_suggested_severity'),
         'automatic_triage':metric.get('automatic_triage'),'automation_eligible':metric.get('automation_eligible')}
    row.update({k:metric.get(k) for k in ['raw_events','incidents','detection_ms','triage_ms','approval_ms','response_ms']})
    rows.append(row)
with (OUT/'rodadas.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
stats={}
for mode in ['manual','auto','llm','failure']:
    selected=[r for r in rows if r['mode']==mode]
    item={'n':len(selected),'scenarios':dict(Counter(r['scenario'] for r in selected))}
    for key in ['detection_ms','triage_ms','approval_ms','response_ms']:
        values=[r[key]/1000 for r in selected if r[key] is not None]
        item[key]={'n':len(values),'mean_s':statistics.mean(values),'median_s':statistics.median(values),
                   'min_s':min(values),'max_s':max(values),'sd_sample_s':statistics.stdev(values) if len(values)>1 else None} if values else {'n':0}
    stats[mode]=item
benchmark=next(x for x in events if x['event']=='siem.benchmark' and x['suite']=='clinic-security-v1')
assert benchmark['counts']=={'tp':3,'fp':1,'fn':3,'tn':1}
with (OUT/'detector.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['scenario','ground_truth','detected','outcome']);w.writeheader();w.writerows(benchmark['cases'])
containments=[]
skews=[]
for row in rows:
    trail=by_run[row['run']]
    applied=[x for x in trail if x['event']=='endpoint.block_applied']
    if not applied:continue
    approval=next(x for x in trail if x['event']=='soar.approval_granted')
    block=applied[0]
    release=next(x for x in trail if x['event']=='endpoint.block_released')
    assert approval['approval_id']==block['approval_id']==release['approval_id']
    assert trail.index(approval)<trail.index(block)
    assert block['ttl_seconds']==45
    assert any(x['event']=='attack.probe' and x['phase']=='contained' and x['http_status']==403 for x in trail)
    assert any(x['event']=='attack.probe' and x['phase']=='legitimate' and x['http_status']==204 for x in trail)
    assert any(x['event']=='attack.probe' and x['phase']=='released' and x['http_status']==204 for x in trail)
    assert any(x['event']=='soar.control_allowed' and x['http_status']==204 for x in trail)
    containments.append({'run':row['run'],'approval_id':approval['approval_id'],'ttl_seconds':45,
                         'approval_timestamp':approval['timestamp'],'block_timestamp':block['timestamp'],
                         'release_timestamp':release['timestamp'],'release_reason':release['reason'],
                         'suspect_http':403,'legitimate_http':204,'control_http':204,'released_http':204})
    if block['timestamp']<approval['timestamp']:skews.append(row['run'])
with (OUT/'contencoes.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(containments[0]));w.writeheader();w.writerows(containments)
eligible=[r for r in rows if r['automation_eligible']]
automatic=[r for r in eligible if r['automatic_triage']]
model_rows=[x for x in events if x['event']=='soar.triaged' and x.get('provider')=='ollama']
assert len(model_rows)==2 and all(x['validation']=='passed' for x in model_rows)
corpus_total=0;session=[]
with gzip.open(SRC/'clinica-investigacao-205k.jsonl.gz','rt',encoding='utf-8') as f:
    for line in f:
        x=json.loads(line);assert x['synthetic'] is True;corpus_total+=1
        if x.get('session_id')=='SES-MED-017':session.append(x)
assert corpus_total==205000 and len(session)==82
assert Counter(x['event_type'] for x in session)=={'auth.login':1,'ehr.record_read':80,'ehr.export_requested':1}
summary={'audit_lines':len(events),'raw_event_records':sum(x['event']=='siem.raw' for x in events),
         'runs':len(rows),'mode_counts':dict(Counter(x['mode'] for x in rows)),
         'stats':stats,'benchmark':benchmark,'containments':len(containments),
         'clock_skew_runs':skews,'automation':{'valid':len(automatic),'eligible':len(eligible),'rate':len(automatic)/len(eligible)},
         'corpus_events':corpus_total,'example_session_events':len(session),'model_outputs':len(model_rows),
         'model_versions':sorted({(x['model'],x['engine_version'],x['model_version'],x['prompt_version']) for x in model_rows}),
         'model_structural_valid':sum(x.get('validation')=='passed' for x in model_rows),
         'model_severity_matches_rule':sum(x['severity']==x['result']['severity'] for x in model_rows),
         'model_generic_reason':sum(x['result']['severity_reason']=='incerteza sobre o autor' for x in model_rows)}
(OUT/'resumo.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
hash_paths=[*SRC.rglob('*'),*OUT.rglob('*'),DATA/'go-tests.jsonl',DATA/'javascript-tests.txt']
hash_paths=[*SRC.rglob('*'),*OUT.rglob('*'),DATA/'go-tests.jsonl',DATA/'javascript-tests.txt']
hash_paths=[*SRC.rglob('*'),*OUT.rglob('*'),DATA/'go-tests.jsonl',DATA/'javascript-tests.txt']
digests={p.relative_to(DATA).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(hash_paths) if p.is_file()}
(DATA/'sha256.json').write_text(json.dumps(digests,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(rows),'source_lines':len(events),'corpus_events':corpus_total,'benchmark_counts':benchmark['counts'],
                  'safe_containments':len(containments),'clock_skew_observed':len(skews),'automation_rate':len(automatic)/len(eligible),'status':'passed'},ensure_ascii=False))
